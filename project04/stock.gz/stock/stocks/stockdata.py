import tushare as ts

class Test(object):
    def getTest(self):
        print('@@')
        pro = ts.pro_api('b280312f2903dbec185c07535e9ab3f67df9bfe2220e08e46742b9b5')
        data = pro.stock_basic(exchange='', list_status='L', fields='ts_code,symbol,name,area,industry,list_date')
        print(data)
        pass

class GetStockData(object):

    def getKdata(self):
        pro = ts.pro_api('b280312f2903dbec185c07535e9ab3f67df9bfe2220e08e46742b9b5')
        data = pro.daily(ts_code='000001.SZ',start_date='20180701',end_date='20180718')
        print(data)
        
        pass

if __name__ == '__main__':
    GetStockData().getKdata()