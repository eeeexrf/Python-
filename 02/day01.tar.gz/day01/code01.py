str_name = input("请输入姓名：")
print("您好："+str_name)