// $(()=>{
//     //加载头部
//     $.get("header.html",(data)=>{
//         $("#header").html(data);
//         $(".login").click((e)=>{
//             e.preventDefault();
//             console.log("aaa");
//             $(location).attr("href","login.html");
//         })
//     }).then(()=>{
//         $(".login-img").click((e)=>{
//             e.preventDefault();
//             $(location).attr("href","index.html");
//         });
//     })
// })

