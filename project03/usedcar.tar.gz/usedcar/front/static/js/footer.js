// /**
//  * Created by tarena on 2018/4/24.
//  */
// $(()=>{
//     //加载底部
//     $.get("footer.html",(data)=>{
//         $("#footer").html(data);
//     })
// })
