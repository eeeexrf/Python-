from django.apps import AppConfig


class UserinfoConfig(AppConfig):
    name = 'userinfo'
