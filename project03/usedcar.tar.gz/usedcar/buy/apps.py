from django.apps import AppConfig


class BuyConfig(AppConfig):
    name = 'buy'
