from django.db import models

# Create your models here.
#收货地址
#收件人
#收件人的收货地址
#手机号
#邮编
#是否默认地址
#别名 家 公司 学校
#关联用户

