from django.apps import AppConfig


class AddressConfig(AppConfig):
    name = 'address'
