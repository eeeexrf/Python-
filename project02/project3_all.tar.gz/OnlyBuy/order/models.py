from django.db import models

# Create your models here.
#订单信息
#订单号
#状态
#实际价格
#......
#关联买家
#关联卖家

#订单商品信息
#关联订单信息
#关联商品
#关联商品卖家
#交易时价格
#.....