#!/usr/bin/env python3
import sys


print("hello world!")

print("以下是Python版本！")

print(sys.version_info)

